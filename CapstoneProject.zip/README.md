Requirements:
- Python 3.7
- Latest PyTorch 
- Some basic Machine Learning packages:
	- nltk
	- numpy
	- torch
	- time

I trained my model on GoogleColab with a GPU acceleration as I found it more easy to use 
and train than the AmazonSageMaker.
I believe that my code could also be run on a local host with little difficulties as long
as users have all the requirements above. 
The Brown dataset used in the project could be easily downloaded with the nltk package. 